# Tipo de Documento (CodeSystem) - Guia de Implementação do Registro de Regulação Assistencial (RIRA) da RNDS v1.0.0

## CodeSystem: Tipo de Documento (CodeSystem) 

Este sistema de códigos é referenciado na definição dos seguintes conjuntos de valores:

* [Tipo de Documento (ValueSet)](ValueSet-BRTipoDocumento-1.0.md)

-------

 [Descrição do(s) quadro(s) acima](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "BRTipoDocumento",
  "language" : "pt-BR",
  "url" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRTipoDocumento",
  "version" : "1.0.0",
  "name" : "BRTipoDocumento",
  "title" : "Tipo de Documento (CodeSystem)",
  "status" : "active",
  "experimental" : false,
  "date" : "2020-03-26T13:19:46.9743559+00:00",
  "publisher" : "Ministério da Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério da Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.saude.gov.br"
    },
    {
      "system" : "email",
      "value" : "cgiis.datasus@saude.gov.br"
    }]
  }],
  "description" : "Classificação dos tipos de documentos compartilhados no Brasil.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "concept" : [{
    "code" : "CMD",
    "display" : "Conjunto Mínimo de Dados",
    "definition" : "Documento público que coleta os dados mínimos dos atendimentos em saúde realizados em qualquer estabelecimento de saúde do país, público ou privado, em cada contato assistencial."
  },
  {
    "code" : "SA",
    "display" : "Sumário de Alta",
    "definition" : "Relato clínico objetivo sobre as intervenções realizadas, as instruções para continuidade do cuidado pós-alta e o estado de saúde do indivíduo ao final de sua permanência na internação em estabelecimentos de saúde como: hospital, clínica, hospital-dia, internação domiciliar e urgência."
  },
  {
    "code" : "RAC",
    "display" : "Registro de Atendimento Clínico",
    "definition" : "Registro de dados essenciais de uma consulta realizada a um indivíduo no âmbito da atenção básica, especializada ou domiciliar (atendimento diário)."
  },
  {
    "code" : "RIA",
    "display" : "Registro de Imunobiológico Administrado"
  },
  {
    "code" : "RPM",
    "display" : "Registro de Prescrição de Medicamento"
  },
  {
    "code" : "RDM",
    "display" : "Registro de Dispensação de Medicamento"
  },
  {
    "code" : "REL",
    "display" : "Resultado de Exame(s) Laboratoriais(s)"
  },
  {
    "code" : "RA",
    "display" : "Regulação Assistencial"
  },
  {
    "code" : "ATM",
    "display" : "Atestado Médico/Odontológico"
  },
  {
    "code" : "REPM",
    "display" : "Registro Eletrônico da Prescrição de Medicamento"
  },
  {
    "code" : "REDFM",
    "display" : "Registro Eletrônico de Dispensação ou Fornecimento de Medicamentos"
  }]
}

```
