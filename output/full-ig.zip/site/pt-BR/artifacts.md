# Resumo de Artefatos - Guia de Implementação do Registro de Regulação Assistencial (RIRA) da RNDS v1.0.0

## Resumo de Artefatos

