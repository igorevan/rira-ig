# Requisição de Regulação Assistencial - Guia de Implementação do Registro de Regulação Assistencial (RIRA) da RNDS v1.0.0-release

## Resource Profile: Requisição de Regulação Assistencial 

 
Requisição de Regulação Assistencial 

**Usos:**

* Refere a este Perfil: [Agendamento de Regulação Assistencial](StructureDefinition-BRAgendamentoRegulacaoAssistencial.md) and [Regulação Assistencial](StructureDefinition-BRRegulacaoAssistencial.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/br.gov.saude.rira.fhir|current/StructureDefinition/StructureDefinition-BRRequisicaoRegulacaoAssistencial.json)

### Formal Views of Profile Content

 [Description Differentials, Snapshots, and other representations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](../StructureDefinition-BRRequisicaoRegulacaoAssistencial.csv), [Excel](../StructureDefinition-BRRequisicaoRegulacaoAssistencial.xlsx), [Schematron](../StructureDefinition-BRRequisicaoRegulacaoAssistencial.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "BRRequisicaoRegulacaoAssistencial",
  "language" : "pt-BR",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-wg",
    "valueCode" : "ehr"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "http://fhir.saude.gov.br/rira/ImplementationGuide/br.gov.saude.rira.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "normative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "http://fhir.saude.gov.br/rira/ImplementationGuide/br.gov.saude.rira.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
    "valueCode" : "4.0.1"
  }],
  "url" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRRequisicaoRegulacaoAssistencial",
  "version" : "1.0.0-release",
  "name" : "BRRequisicaoRegulacaoAssistencial",
  "title" : "Requisição de Regulação Assistencial",
  "status" : "active",
  "date" : "2023-04-04",
  "publisher" : "Ministério da Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério da Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.saude.gov.br"
    },
    {
      "system" : "email",
      "value" : "cgiis.datasus@saude.gov.br"
    }]
  }],
  "description" : "Requisição de Regulação Assistencial",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "quick",
    "uri" : "http://siframework.org/cqf",
    "name" : "Quality Improvement and Clinical Knowledge (QUICK)"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "ServiceRequest",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/ServiceRequest",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "ServiceRequest",
      "path" : "ServiceRequest",
      "constraint" : [{
        "key" : "mira-1",
        "severity" : "error",
        "human" : "O Motivo da Solicitação (Condition.code) deve ser preenchido caso a Data da Solicitação (ServiceRequest.authoredOn) seja posterior a 01/01/2025.",
        "expression" : "(authoredOn > @2025-01-01T01:00:00) implies reasonReference.resolve().code.exists()"
      }]
    },
    {
      "id" : "ServiceRequest.id",
      "path" : "ServiceRequest.id",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.implicitRules",
      "path" : "ServiceRequest.implicitRules",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.language",
      "path" : "ServiceRequest.language",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.text",
      "path" : "ServiceRequest.text",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.contained",
      "path" : "ServiceRequest.contained",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.identifier",
      "path" : "ServiceRequest.identifier",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.instantiatesCanonical",
      "path" : "ServiceRequest.instantiatesCanonical",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.instantiatesUri",
      "path" : "ServiceRequest.instantiatesUri",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.basedOn",
      "path" : "ServiceRequest.basedOn",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.replaces",
      "path" : "ServiceRequest.replaces",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.requisition",
      "path" : "ServiceRequest.requisition",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.status",
      "path" : "ServiceRequest.status",
      "condition" : ["mira-13",
      "mira-14",
      "mira-15",
      "mira-16",
      "mira-17",
      "mira-18",
      "mira-19"],
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://www.saude.gov.br/fhir/r4/ValueSet/BRStatusRequisicaoRegulacaoAssistencial"
      }
    },
    {
      "id" : "ServiceRequest.intent",
      "path" : "ServiceRequest.intent",
      "short" : "proposal | plan |  directive | order | original-order | reflex-order | filler-order | instance-order | option",
      "fixedCode" : "proposal",
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://www.saude.gov.br/fhir/r4/ValueSet/BRIntencaoRegulacao"
      }
    },
    {
      "id" : "ServiceRequest.category",
      "path" : "ServiceRequest.category",
      "short" : "Modalidade assistencial",
      "definition" : "Modalidade assistencial que gerou a solicitação do procedimento.",
      "min" : 1,
      "max" : "1",
      "binding" : {
        "strength" : "required",
        "description" : "Modalidade assistencial.",
        "valueSet" : "http://www.saude.gov.br/fhir/r4/ValueSet/BRModalidadeAssistencialMIRA"
      }
    },
    {
      "id" : "ServiceRequest.category.id",
      "path" : "ServiceRequest.category.id",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.category.coding",
      "path" : "ServiceRequest.category.coding",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "ServiceRequest.category.coding.id",
      "path" : "ServiceRequest.category.coding.id",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.category.coding.system",
      "path" : "ServiceRequest.category.coding.system",
      "min" : 1
    },
    {
      "id" : "ServiceRequest.category.coding.code",
      "path" : "ServiceRequest.category.coding.code",
      "min" : 1
    },
    {
      "id" : "ServiceRequest.category.coding.userSelected",
      "path" : "ServiceRequest.category.coding.userSelected",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.category.text",
      "path" : "ServiceRequest.category.text",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.priority",
      "path" : "ServiceRequest.priority",
      "short" : "Caráter da solicitação",
      "definition" : "Modalidade assistencial que gerou a solicitação do procedimento.",
      "min" : 1,
      "binding" : {
        "strength" : "required",
        "description" : "Caráter do atendimento",
        "valueSet" : "http://www.saude.gov.br/fhir/r4/ValueSet/BRCaraterAtendimentoMIRA"
      }
    },
    {
      "id" : "ServiceRequest.doNotPerform",
      "path" : "ServiceRequest.doNotPerform",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.code",
      "path" : "ServiceRequest.code",
      "short" : "Código do procedimento",
      "definition" : "O código que identifica unicamente o procedimento conforme tabela SUS.",
      "min" : 1,
      "binding" : {
        "strength" : "required",
        "description" : "SIGTAP",
        "valueSet" : "http://www.saude.gov.br/fhir/r4/ValueSet/BRProcedimentosNacionais-1.0"
      }
    },
    {
      "id" : "ServiceRequest.code.id",
      "path" : "ServiceRequest.code.id",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.code.coding",
      "path" : "ServiceRequest.code.coding",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "ServiceRequest.code.coding.id",
      "path" : "ServiceRequest.code.coding.id",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.code.coding.system",
      "path" : "ServiceRequest.code.coding.system",
      "min" : 1
    },
    {
      "id" : "ServiceRequest.code.coding.code",
      "path" : "ServiceRequest.code.coding.code",
      "min" : 1
    },
    {
      "id" : "ServiceRequest.code.coding.userSelected",
      "path" : "ServiceRequest.code.coding.userSelected",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.code.text",
      "path" : "ServiceRequest.code.text",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.orderDetail",
      "path" : "ServiceRequest.orderDetail",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.quantity[x]",
      "path" : "ServiceRequest.quantity[x]",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.subject",
      "path" : "ServiceRequest.subject",
      "short" : "Identificador do paciente",
      "definition" : "Identificação única do paciente, por meio de CPF ou CNS.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0"]
      }]
    },
    {
      "id" : "ServiceRequest.subject.id",
      "path" : "ServiceRequest.subject.id",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.subject.reference",
      "path" : "ServiceRequest.subject.reference",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.subject.type",
      "path" : "ServiceRequest.subject.type",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.subject.identifier",
      "path" : "ServiceRequest.subject.identifier",
      "min" : 1,
      "constraint" : [{
        "key" : "ident-1",
        "severity" : "error",
        "human" : "O número de CPF ou CNS informado é inválido (subject.identifier.value).",
        "expression" : "value.matches('^(?!(\\\\d)\\\\1{10})\\\\d{11}$') or value.matches('^(?!(\\\\d)\\\\1{14})[125789]\\\\d{14}$')"
      }]
    },
    {
      "id" : "ServiceRequest.subject.identifier.id",
      "path" : "ServiceRequest.subject.identifier.id",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.subject.identifier.use",
      "path" : "ServiceRequest.subject.identifier.use",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.subject.identifier.type",
      "path" : "ServiceRequest.subject.identifier.type",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.subject.identifier.system",
      "path" : "ServiceRequest.subject.identifier.system",
      "min" : 1
    },
    {
      "id" : "ServiceRequest.subject.identifier.value",
      "path" : "ServiceRequest.subject.identifier.value",
      "min" : 1
    },
    {
      "id" : "ServiceRequest.subject.identifier.period",
      "path" : "ServiceRequest.subject.identifier.period",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.subject.identifier.assigner",
      "path" : "ServiceRequest.subject.identifier.assigner",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.subject.display",
      "path" : "ServiceRequest.subject.display",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.encounter",
      "path" : "ServiceRequest.encounter",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.occurrence[x]",
      "path" : "ServiceRequest.occurrence[x]",
      "short" : "Data da execução",
      "definition" : "A data e hora em que o procedimento regulado foi executado no padrão ISO 8601.",
      "type" : [{
        "code" : "dateTime"
      }],
      "condition" : ["mira-3", "mira-9", "mira-12"]
    },
    {
      "id" : "ServiceRequest.occurrence[x].id",
      "path" : "ServiceRequest.occurrence[x].id",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.asNeeded[x]",
      "path" : "ServiceRequest.asNeeded[x]",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.authoredOn",
      "path" : "ServiceRequest.authoredOn",
      "short" : "Data da solicitação",
      "definition" : "A data e hora da solicitação do procedimento regulado no padrão ISO 8601.",
      "min" : 1,
      "condition" : ["mira-1"]
    },
    {
      "id" : "ServiceRequest.requester",
      "path" : "ServiceRequest.requester",
      "short" : "Estabelecimento de saúde solicitante",
      "definition" : "Identificação única do estabelecimento solicitante, por meio do CNES.",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BREstabelecimentoSaude-1.0"]
      }]
    },
    {
      "id" : "ServiceRequest.requester.id",
      "path" : "ServiceRequest.requester.id",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.requester.reference",
      "path" : "ServiceRequest.requester.reference",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.requester.type",
      "path" : "ServiceRequest.requester.type",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.requester.identifier",
      "path" : "ServiceRequest.requester.identifier",
      "min" : 1,
      "constraint" : [{
        "key" : "estab-2",
        "severity" : "error",
        "human" : "O número do CNES do estabelecimento de saúde é inválido (identifier.value). O número deve conter 7 dígitos e não pode conter letras ou caracteres especiais, apenas números.",
        "expression" : "value.matches('^(?!(\\\\d)\\\\1{6})\\\\d{7}$')"
      }]
    },
    {
      "id" : "ServiceRequest.requester.identifier.id",
      "path" : "ServiceRequest.requester.identifier.id",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.requester.identifier.use",
      "path" : "ServiceRequest.requester.identifier.use",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.requester.identifier.type",
      "path" : "ServiceRequest.requester.identifier.type",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.requester.identifier.system",
      "path" : "ServiceRequest.requester.identifier.system",
      "min" : 1
    },
    {
      "id" : "ServiceRequest.requester.identifier.value",
      "path" : "ServiceRequest.requester.identifier.value",
      "min" : 1
    },
    {
      "id" : "ServiceRequest.requester.identifier.period",
      "path" : "ServiceRequest.requester.identifier.period",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.requester.identifier.assigner",
      "path" : "ServiceRequest.requester.identifier.assigner",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.requester.display",
      "path" : "ServiceRequest.requester.display",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.performerType",
      "path" : "ServiceRequest.performerType",
      "short" : "Especialidade médica do executante",
      "definition" : "Identificação da especialidade médica do profissional executante do procedimento, conforme tabela de CBO. \r\nCaso o procedimento informado pertença à forma de organização 03.01.01 da tabela SUS, o código CBO será obrigatório.",
      "binding" : {
        "strength" : "required",
        "description" : "Classificação Brasileira de Ocupações.",
        "valueSet" : "http://www.saude.gov.br/fhir/r4/ValueSet/BROcupacao-1.0"
      }
    },
    {
      "id" : "ServiceRequest.performerType.id",
      "path" : "ServiceRequest.performerType.id",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.performerType.coding",
      "path" : "ServiceRequest.performerType.coding",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "ServiceRequest.performerType.coding.id",
      "path" : "ServiceRequest.performerType.coding.id",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.performerType.coding.system",
      "path" : "ServiceRequest.performerType.coding.system",
      "min" : 1
    },
    {
      "id" : "ServiceRequest.performerType.coding.code",
      "path" : "ServiceRequest.performerType.coding.code",
      "min" : 1
    },
    {
      "id" : "ServiceRequest.performerType.coding.userSelected",
      "path" : "ServiceRequest.performerType.coding.userSelected",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.performerType.text",
      "path" : "ServiceRequest.performerType.text",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.performer",
      "path" : "ServiceRequest.performer",
      "short" : "Estabelecimento de saúde executante",
      "definition" : "Identificação única do estabelecimento executante, por meio do CNES.",
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BREstabelecimentoSaude-1.0"]
      }],
      "condition" : ["mira-4", "mira-6", "mira-8", "mira-11"]
    },
    {
      "id" : "ServiceRequest.performer.id",
      "path" : "ServiceRequest.performer.id",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.performer.reference",
      "path" : "ServiceRequest.performer.reference",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.performer.type",
      "path" : "ServiceRequest.performer.type",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.performer.identifier",
      "path" : "ServiceRequest.performer.identifier",
      "min" : 1,
      "constraint" : [{
        "key" : "estab-2",
        "severity" : "error",
        "human" : "O número do CNES do estabelecimento de saúde é inválido (identifier.value). O número deve conter 7 dígitos e não pode conter letras ou caracteres especiais, apenas números.",
        "expression" : "value.matches('^(?!(\\\\d)\\\\1{6})\\\\d{7}$')"
      }]
    },
    {
      "id" : "ServiceRequest.performer.identifier.id",
      "path" : "ServiceRequest.performer.identifier.id",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.performer.identifier.use",
      "path" : "ServiceRequest.performer.identifier.use",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.performer.identifier.type",
      "path" : "ServiceRequest.performer.identifier.type",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.performer.identifier.system",
      "path" : "ServiceRequest.performer.identifier.system",
      "min" : 1
    },
    {
      "id" : "ServiceRequest.performer.identifier.value",
      "path" : "ServiceRequest.performer.identifier.value",
      "min" : 1
    },
    {
      "id" : "ServiceRequest.performer.identifier.period",
      "path" : "ServiceRequest.performer.identifier.period",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.performer.identifier.assigner",
      "path" : "ServiceRequest.performer.identifier.assigner",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.performer.display",
      "path" : "ServiceRequest.performer.display",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.locationCode",
      "path" : "ServiceRequest.locationCode",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.locationReference",
      "path" : "ServiceRequest.locationReference",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.reasonCode",
      "path" : "ServiceRequest.reasonCode",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.reasonReference",
      "path" : "ServiceRequest.reasonReference",
      "short" : "Motivo da solicitação",
      "definition" : "Identificação do motivo da solicitação do procedimento, conforme Classificação Internacional de Doenças - CID ou Classificação Internacional de Atenção Primária - CIAP.",
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRProblemaDiagnostico"]
      }]
    },
    {
      "id" : "ServiceRequest.reasonReference.id",
      "path" : "ServiceRequest.reasonReference.id",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.reasonReference.reference",
      "path" : "ServiceRequest.reasonReference.reference",
      "min" : 1
    },
    {
      "id" : "ServiceRequest.reasonReference.type",
      "path" : "ServiceRequest.reasonReference.type",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.reasonReference.identifier",
      "path" : "ServiceRequest.reasonReference.identifier",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.reasonReference.display",
      "path" : "ServiceRequest.reasonReference.display",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.insurance",
      "path" : "ServiceRequest.insurance",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.supportingInfo",
      "path" : "ServiceRequest.supportingInfo",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.specimen",
      "path" : "ServiceRequest.specimen",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.bodySite",
      "path" : "ServiceRequest.bodySite",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.note",
      "path" : "ServiceRequest.note",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.patientInstruction",
      "path" : "ServiceRequest.patientInstruction",
      "max" : "0"
    },
    {
      "id" : "ServiceRequest.relevantHistory",
      "path" : "ServiceRequest.relevantHistory",
      "max" : "0"
    }]
  }
}

```
