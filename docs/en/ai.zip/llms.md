# br.gov.saude.rira.fhir#1.0.0-release: Guia de Implementação do Registro de Regulação Assistencial (RIRA) da RNDS(en)

## Pages

* [Principal](index.md)
* [Credenciamento](credenciamento.md)
* [Modelo Computacional](mc.md)
* [Downloads](downloads.md)
* [Suporte da RNDS](suporte.md)
* [Feedback](forms.md)
* [Abstract](abstract.md)
* [Integração](integracao.md)
* [Artifacts Summary](artifacts.md)
* [Histórico de mudanças](changes.md)
* [Exemplos](exemplos.md)
* [Modelo de Informação](mi.md)

## Resources

### CodeSystems

* [Classificação Brasileira Hierarquizada de Procedimentos Médicos (CBHPM) e da Terminologia Unificada da Saúde Suplementar (TUSS)](CodeSystem-BRCBHPMTUSS.md)
* [Classificação Brasileira de Ocupações (CBO)](CodeSystem-BRCBO.md)
* [Classificação Internacional de Atenção Primária - Segunda Edição - CIAP2](CodeSystem-BRCIAP2.md)
* [Classificação Internacional de Doenças - Décima Revisão (CID-10)](CodeSystem-BRCID10.md)
* [Categoria do Diagnóstico (CodeSystem)](CodeSystem-BRCategoriaDiagnostico.md)
* [Justificativa da Impossibilidade de Identificação do Indivíduo (CodeSystem)](CodeSystem-BRJustificativaIndividuoNaoIdentificado.md)
* [Modalidade Assistencial](CodeSystem-BRModalidadeAssistencial.md)
* [Status de agendamento de regulação assistencial (CodeSystem)](CodeSystem-BRStatusAgendamentoRegulacaoAssistencial.md)
* [Status da regulação assistencial](CodeSystem-BRStatusRegulacaoAssistencial.md)
* [Tabela de procedimentos, medicamentos e OPM do SUS](CodeSystem-BRTabelaSUS.md)
* [Tipo de Documento (CodeSystem)](CodeSystem-BRTipoDocumento.md)
* [Tipo do Participante](CodeSystem-BRTipoParticipante.md)

### ValueSets

* [Classificação Internacional de Doenças - Décima Revisão - CID-10](ValueSet-BRCID10-1.0.md)
* [Caráter de Atendimento no MIRA](ValueSet-BRCaraterAtendimentoMIRA.md)
* [Classificação de uma condição](ValueSet-BRCategoriaCondicao.md)
* [Estado do Documento](ValueSet-BREstadoDocumento-1.0.md)
* [Estado da Resolução de Diagnóstico ou Problema](ValueSet-BREstadoResolucaoDiagnosticoProblema-1.0.md)
* [Intenção de requisição de regulação assistencial](ValueSet-BRIntencaoRegulacao.md)
* [Justificativa da Impossibilidade de Identificação do Indivíduo (ValueSet)](ValueSet-BRJustificativaIndividuoNaoIdentificado-1.0.md)
* [Modalidade Assistencial MIRA](ValueSet-BRModalidadeAssistencialMIRA.md)
* [Classificação Brasileira de Ocupações - CBO](ValueSet-BROcupacao-1.0.md)
* [Classificação Internacional de Doenças e Atenção Primária](ValueSet-BRProblemaDiagnostico.md)
* [Procedimento realizado](ValueSet-BRProcedimentosNacionais-1.0.md)
* [Sexo](ValueSet-BRSexo-1.0.md)
* [Status de agendamento de regulação assistencial (ValueSet)](ValueSet-BRStatusAgendamentoRegulacaoAssistencial.md)
* [Status do Participante do agendamento](ValueSet-BRStatusParticipante.md)
* [Status de regulação assistencial](ValueSet-BRStatusRegulacaoAssistencial.md)
* [Status de requisição de regulação assistencial](ValueSet-BRStatusRequisicaoRegulacaoAssistencial.md)
* [Tipo de Documento (ValueSet)](ValueSet-BRTipoDocumento-1.0.md)
* [Tipo Participante](ValueSet-BRTipoParticipante.md)

### Resource Profiles

* [Agendamento de Regulação Assistencial](StructureDefinition-BRAgendamentoRegulacaoAssistencial.md)
* [Problema/Diagnóstico](StructureDefinition-BRProblemaDiagnostico.md)
* [Regulação Assistencial](StructureDefinition-BRRegulacaoAssistencial.md)
* [Requisição de Regulação Assistencial](StructureDefinition-BRRequisicaoRegulacaoAssistencial.md)

### Extensions

* [Informações Complementares de Indivíduos Não Identificados](StructureDefinition-BRIndividuoNaoIdentificado-1.0.md)

### ImplementationGuides

* [Guia de Implementação do Registro de Regulação Assistencial (RIRA) da RNDS](ImplementationGuide-br.gov.saude.rira.fhir.md)

### Examples

* [example-rira-anterior-2025-com-ciap (Bundle)](Bundle-example-rira-anterior-2025-com-ciap.md)
* [example-rira-anterior-2025-com-cid (Bundle)](Bundle-example-rira-anterior-2025-com-cid.md)
* [example-rira-anterior-2025-sem-cid-ciap (Bundle)](Bundle-example-rira-anterior-2025-sem-cid-ciap.md)
* [example-rira-anterior-2025-sem-cid (Bundle)](Bundle-example-rira-anterior-2025-sem-cid.md)
* [example-rira-pendente-com-ciap (Bundle)](Bundle-example-rira-pendente-com-ciap.md)
* [example-rira-posterior-2025-com-ciap (Bundle)](Bundle-example-rira-posterior-2025-com-ciap.md)
* [example-rira-posterior-2025-com-cid (Bundle)](Bundle-example-rira-posterior-2025-com-cid.md)
