# Bundle de exemplo do RIRA (Agendado) - Guia de Implementação da Regulação Assistencial (RIRA) da RNDS v1.0.0

* [**Índice**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bundle de exemplo do RIRA (Agendado)**

## Example Bundle: Bundle de exemplo do RIRA (Agendado)

**Document Details**

Última atualização: 2024-02-27 17:11:44-0300

Final Documento em 2024-02-27 17:11:44-0300 por Identifier: `http://www.saude.gov.br/fhir/r4/StructureDefinition/BREstabelecimentoSaude-1.0`/5604613 para Identifier: `http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0`/706004324048847 

-------

-------

**Document Content**

-------

## Recursos adicionais incluídos no documento

-------

Entrada 2 - fullUrl = urn:uuid:transient-1

Recurso Appointment:

> 

Última atualização: 2024-02-27 17:11:44-0300

Perfil: [Agendamento de Regulação Assistencial](StructureDefinition-BRAgendamentoRegulacaoAssistencial.md)

**status**: Booked**serviceCategory**:Assistência Ambulatorial**serviceType**: Nenhum ecrã para Appointment.serviceType (concept: CONSULTA MEDICA EM ATENÇÃO ESPECIALIZADA)**specialty**:MEDICO PNEUMOLOGISTA**appointmentType**:Routine**start**: 2019-03-17 21:00:00-0300**end**: 2019-03-17 21:00:00-0300**created**: 2019-01-16 22:00:00-0200**basedOn**:[ServiceRequest CONSULTA MEDICA EM ATENÇÃO ESPECIALIZADA](Bundle-Example-RIRA-Attended.md#urn-uuid-transient-2)

### Participants

| | | | |
| :--- | :--- | :--- | :--- |
| - | **Type** | **Actor** | **Status** |
| * | Paciente | Identifier:`http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0`/706004324048847 | Accepted |


-------

Entrada 3 - fullUrl = urn:uuid:transient-2

Recurso ServiceRequest:

> 

Última atualização: 2024-02-27 17:11:44-0300

Perfil: [Requisição de Regulação Assistencial](StructureDefinition-BRRequisicaoRegulacaoAssistencial.md)

**status**: Active**intent**: Order**category**:Assistência Ambulatorial**priority**: Urgent**code**: Nenhum ecrã para ServiceRequest.code (concept: CONSULTA MEDICA EM ATENÇÃO ESPECIALIZADA)**subject**: Identifier:`http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0`/706004324048847**authoredOn**: 2019-01-16 22:00:00-0200**requester**: Identifier:`http://www.saude.gov.br/fhir/r4/StructureDefinition/BREstabelecimentoSaude-1.0`/6689477**performerType**:MEDICO PNEUMOLOGISTA

-------

Entrada 4 - fullUrl = urn:uuid:transient-3

Recurso Condition:

> 

Última atualização: 2024-02-27 17:11:44-0300

Perfil: [CID10 Avaliado](StructureDefinition-BRCID10Avaliado-1.0.md)

**code**:Anormalidades da respiração**subject**: Identifier:`http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0`/706004324048847



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "Example-RIRA-Booked",
  "meta" : {
    "lastUpdated" : "2024-02-27T17:11:44-03:00"
  },
  "identifier" : {
    "system" : "http://www.saude.gov.br/fhir/r4/NamingSystem/BRRNDS-1964",
    "value" : "AMB_271831370_0701172"
  },
  "type" : "document",
  "timestamp" : "2024-02-27T17:11:44-03:00",
  "entry" : [
    {
      "fullUrl" : "urn:uuid:transient-0",
      "resource" : {
        "resourceType" : "Composition",
        "meta" : {
          "lastUpdated" : "2024-02-27T17:11:44-03:00",
          "profile" : [
            "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRRegulacaoAssistencial"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Composition_null\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Composition </b></p><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Última atualização: 2024-02-27 17:11:44-0300</p><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRRegulacaoAssistencial.html\">Regulação Assistencial (RIRA)</a></p></div><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRTipoDocumento RA}\">Regulação Assistencial</span></p><p><b>category</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRModalidadeAssistencial 09}\">Assistência Ambulatorial</span></p><p><b>date</b>: 2024-02-27 17:11:44-0300</p><p><b>author</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BREstabelecimentoSaude-1.0</code>/5604613</p><p><b>title</b>: Registro de Informações da Regulação Assistencial</p><blockquote><p><b>event</b></p><p><b>code</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRStatusRegulacaoAssistencial booked}\">Agendado</span></p><p><b>period</b>: 2019-03-07 12:00:00-0300 --&gt; 2019-03-07 12:00:00-0300</p><p><b>detail</b>: </p><ul><li>Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BREstabelecimentoSaude-1.0</code>/5604613</li><li><a href=\"Bundle-Example-RIRA-Attended.html#urn-uuid-transient-1\">Appointment: status = fulfilled; serviceCategory = Assistência Ambulatorial; serviceType = CONSULTA MEDICA EM ATENÇÃO ESPECIALIZADA; specialty = MEDICO PNEUMOLOGISTA; appointmentType = Routine; start = 2019-03-17 21:00:00-0300; end = 2019-03-17 21:00:00-0300; created = 2019-01-16 22:00:00-0200</a></li></ul></blockquote></div>"
        },
        "status" : "final",
        "type" : {
          "coding" : [
            {
              "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRTipoDocumento",
              "code" : "RA"
            }
          ]
        },
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRModalidadeAssistencial",
                "code" : "09"
              }
            ]
          }
        ],
        "subject" : {
          "identifier" : {
            "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
            "value" : "706004324048847"
          }
        },
        "date" : "2024-02-27T17:11:44-03:00",
        "author" : [
          {
            "identifier" : {
              "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BREstabelecimentoSaude-1.0",
              "value" : "5604613"
            }
          }
        ],
        "title" : "Registro de Informações da Regulação Assistencial",
        "event" : [
          {
            "code" : [
              {
                "coding" : [
                  {
                    "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRStatusRegulacaoAssistencial",
                    "code" : "booked"
                  }
                ]
              }
            ],
            "period" : {
              "start" : "2019-03-07T12:00:00-03:00",
              "end" : "2019-03-07T12:00:00-03:00"
            },
            "detail" : [
              {
                "identifier" : {
                  "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BREstabelecimentoSaude-1.0",
                  "value" : "5604613"
                }
              },
              {
                "reference" : "urn:uuid:transient-1"
              }
            ]
          }
        ],
        "section" : [
          {
            "entry" : [
              {
                "reference" : "urn:uuid:transient-1"
              }
            ]
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:transient-1",
      "resource" : {
        "resourceType" : "Appointment",
        "meta" : {
          "lastUpdated" : "2024-02-27T17:11:44-03:00",
          "profile" : [
            "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRAgendamentoRegulacaoAssistencial"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Appointment_null\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Appointment </b></p><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Última atualização: 2024-02-27 17:11:44-0300</p><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRAgendamentoRegulacaoAssistencial.html\">Agendamento de Regulação Assistencial</a></p></div><p><b>status</b>: Booked</p><p><b>serviceCategory</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRModalidadeAssistencial 09}\">Assistência Ambulatorial</span></p><p><b>serviceType</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRTabelaSUS 0301010072}\">CONSULTA MEDICA EM ATENÇÃO ESPECIALIZADA</span></p><p><b>specialty</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRCBO 225127}\">MEDICO PNEUMOLOGISTA</span></p><p><b>appointmentType</b>: <span title=\"Códigos:{http://hl7.org/fhir/request-priority routine}\">Routine</span></p><p><b>reasonReference</b>: <a href=\"Bundle-Example-RIRA-Attended.html#urn-uuid-transient-3\">Condition Anormalidades da respiração</a></p><p><b>start</b>: 2019-03-17 21:00:00-0300</p><p><b>end</b>: 2019-03-17 21:00:00-0300</p><p><b>created</b>: 2019-01-16 22:00:00-0200</p><p><b>basedOn</b>: <a href=\"Bundle-Example-RIRA-Attended.html#urn-uuid-transient-2\">ServiceRequest CONSULTA MEDICA EM ATENÇÃO ESPECIALIZADA</a></p><h3>Participants</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Actor</b></td><td><b>Status</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRTipoParticipante PCT}\">Paciente</span></td><td>Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0</code>/706004324048847</td><td>Accepted</td></tr></table></div>"
        },
        "status" : "booked",
        "serviceCategory" : [
          {
            "coding" : [
              {
                "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRModalidadeAssistencial",
                "code" : "09"
              }
            ]
          }
        ],
        "serviceType" : [
          {
            "coding" : [
              {
                "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRTabelaSUS",
                "code" : "0301010072"
              }
            ]
          }
        ],
        "specialty" : [
          {
            "coding" : [
              {
                "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRCBO",
                "code" : "225127"
              }
            ]
          }
        ],
        "appointmentType" : {
          "coding" : [
            {
              "system" : "http://hl7.org/fhir/request-priority",
              "code" : "routine"
            }
          ]
        },
        "reasonReference" : [
          {
            "reference" : "urn:uuid:transient-3"
          }
        ],
        "start" : "2019-03-17T21:00:00.000-03:00",
        "end" : "2019-03-17T21:00:00.000-03:00",
        "created" : "2019-01-16T22:00:00.000-02:00",
        "basedOn" : [
          {
            "reference" : "urn:uuid:transient-2"
          }
        ],
        "participant" : [
          {
            "type" : [
              {
                "coding" : [
                  {
                    "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRTipoParticipante",
                    "code" : "PCT"
                  }
                ]
              }
            ],
            "actor" : {
              "identifier" : {
                "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
                "value" : "706004324048847"
              }
            },
            "status" : "accepted"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:transient-2",
      "resource" : {
        "resourceType" : "ServiceRequest",
        "meta" : {
          "lastUpdated" : "2024-02-27T17:11:44-03:00",
          "profile" : [
            "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRRequisicaoRegulacaoAssistencial"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ServiceRequest_null\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: ServiceRequest </b></p><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Última atualização: 2024-02-27 17:11:44-0300</p><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRRequisicaoRegulacaoAssistencial.html\">Requisição de Regulação Assistencial</a></p></div><p><b>status</b>: Active</p><p><b>intent</b>: Order</p><p><b>category</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRModalidadeAssistencial 09}\">Assistência Ambulatorial</span></p><p><b>priority</b>: Urgent</p><p><b>code</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRTabelaSUS 0301010072}\">CONSULTA MEDICA EM ATENÇÃO ESPECIALIZADA</span></p><p><b>subject</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0</code>/706004324048847</p><p><b>authoredOn</b>: 2019-01-16 22:00:00-0200</p><p><b>requester</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BREstabelecimentoSaude-1.0</code>/6689477</p><p><b>performerType</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRCBO 225127}\">MEDICO PNEUMOLOGISTA</span></p><p><b>reasonReference</b>: <a href=\"Bundle-Example-RIRA-Attended.html#urn-uuid-transient-3\">Condition Anormalidades da respiração</a></p></div>"
        },
        "status" : "active",
        "intent" : "order",
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRModalidadeAssistencial",
                "code" : "09"
              }
            ]
          }
        ],
        "priority" : "urgent",
        "code" : {
          "coding" : [
            {
              "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRTabelaSUS",
              "code" : "0301010072"
            }
          ]
        },
        "subject" : {
          "identifier" : {
            "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
            "value" : "706004324048847"
          }
        },
        "authoredOn" : "2019-01-16T22:00:00.000-02:00",
        "requester" : {
          "identifier" : {
            "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BREstabelecimentoSaude-1.0",
            "value" : "6689477"
          }
        },
        "performerType" : {
          "coding" : [
            {
              "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRCBO",
              "code" : "225127"
            }
          ]
        },
        "reasonReference" : [
          {
            "reference" : "urn:uuid:transient-3"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:transient-3",
      "resource" : {
        "resourceType" : "Condition",
        "meta" : {
          "lastUpdated" : "2024-02-27T17:11:44-03:00",
          "profile" : [
            "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRCID10Avaliado-1.0"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_null\"> </a><p class=\"res-header-id\"><b>Narrativa gerada: Condition </b></p><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Última atualização: 2024-02-27 17:11:44-0300</p><p style=\"margin-bottom: 0px\">Perfil: <a href=\"StructureDefinition-BRCID10Avaliado-1.0.html\">CID10 Avaliado</a></p></div><p><b>code</b>: <span title=\"Códigos:{http://www.saude.gov.br/fhir/r4/CodeSystem/BRCID10 R06}\">Anormalidades da respiração</span></p><p><b>subject</b>: Identifier: <code>http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0</code>/706004324048847</p></div>"
        },
        "code" : {
          "coding" : [
            {
              "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRCID10",
              "code" : "R06"
            }
          ]
        },
        "subject" : {
          "identifier" : {
            "system" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0",
            "value" : "706004324048847"
          }
        }
      }
    }
  ]
}

```
